# Copyright (C) 2026 Vijayaraj Paramasivam. Licensed under the GNU GPLv3.
from . import main

if __name__ == "__main__":
    main()
